extern "C" {
#include "./operator_api.h"
}
// #include <chrono> //计时用的

#include <memory>
#include <iostream>
#include <vector>
#include <string.h>



/*
If you are trying to read this program, please read the document of lidar drive SDK, it should be at ./doc
Especially 03_thread_model.md is the most important doc, it explains that why it use two queues.
And, this file, is modified from ./demo/demo_online.cpp
I think reading that file will help you a lot.

The only thing I modify in the SDK is 'regExceptionCallback'
I changed its return from void to string. The original function is designed to print error massage to console, so I
changed it to return error massage.

*/



class Operator
{
public:
  Operator();
  ~Operator();

};

Operator::Operator()
{

}
Operator::~Operator()
{

}

extern "C" DoraInitResult_t dora_init_operator()
{
  Operator* op = std::make_unique<Operator>().release();  // 创建了一个智能指针
  DoraInitResult_t result = { .operator_context =
                                  (void*)op };  // 这里新建了一个结构体，“内容”指向了一个智能指针，“事件”指向NULL
  return result;
}

extern "C" DoraResult_t dora_drop_operator(void* operator_context)  // 删除函数
{
  delete (Operator*)operator_context;  // 调用析构函数，因为这个示例里面构造函数啥都没有，析构也没写。
  return {};                           // 直接返回一个空结构体，不装了
}

extern "C" OnEventResult_t dora_on_event(  // 事件函数，一个很重要的问题是搞清楚里面的三个形参分别是干什么的
    const RawEvent_t* event,  // 应该是输入事件，
    const SendOutput_t*
        send_output,  // 这个玩意规定了输出内容的形式和报错结果，报错具体规定方法是在里面的call函数，就是
                      // 数据==自己设计怎么做==》字节流（装在）==call函数==》result，输出内容是一个字节流，具体怎么读，《鬼知道》
    void* operator_context)
{
  Operator* op = (Operator*)operator_context;
  if (event->input != NULL)
  {
    // input event

    

    const char* out_id = "array";
    char* out_id_heap = strdup(out_id);
    Vec_uint8 d;
    d.cap=100;
    d.len=100;
    d.ptr=new uint8_t[100];
    for(int i=0;i<100;i++){d.ptr[i]=i;}
    Output_t output = {.id = {
                               .ptr = (uint8_t *)out_id_heap,
                               .len = strlen(out_id_heap),
                               .cap = strlen(out_id_heap) + 1,
                           },
                           .data = d};//这里其实还可以附一份metadata，它没用
                           output.data.ptr=d.ptr;
    DoraResult_t send_result = (send_output->send_output.call)(
        send_output->send_output.env_ptr,
        output);  // 这里用了输入的call函数处理输出的内容，生成一个可能存在的错误，结果装在一个字节流里

    OnEventResult_t result = { .result = send_result, .status = DORA_STATUS_CONTINUE };

    return result;
  }
  if (event->stop)
  {
    printf("C operator received stop event\n");
  }

  OnEventResult_t result = { .status = DORA_STATUS_CONTINUE };
  return result;
}