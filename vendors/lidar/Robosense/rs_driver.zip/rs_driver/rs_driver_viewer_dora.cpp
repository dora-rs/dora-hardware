/*********************************************************************************************************************
Copyright (c) 2020 RoboSense
All rights reserved

By downloading, copying, installing or using the software you agree to this license. If you do not agree to this
license, do not download, install, copy or use the software.

License Agreement
For RoboSense LiDAR SDK Library
(3-clause BSD License)

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following
disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the names of the RoboSense, nor Suteng Innovation Technology, nor the names of other contributors may be used
to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*********************************************************************************************************************/

#include <rs_driver/api/lidar_driver.hpp>
#include <rs_driver/msg/pcl_point_cloud_msg.hpp>

#include <pcl/point_types.h>
#include <pcl/visualization/pcl_visualizer.h>

extern "C"
{
#include "./operator_api.h"
}

#include <memory>
#include <iostream>
#include <vector>
#include <string.h>




using namespace robosense::lidar;
using namespace pcl::visualization;

typedef PointCloudT<PointXYZI> PointCloudMsg;

std::shared_ptr<PCLVisualizer> pcl_viewer;
std::mutex mtx_viewer;

SyncQueue<std::shared_ptr<PointCloudMsg>> free_cloud_queue;
SyncQueue<std::shared_ptr<PointCloudMsg>> stuffed_cloud_queue;



class Operator
{
public:
    Operator();
};

Operator::Operator() {}//构造函数

extern "C" DoraInitResult_t dora_init_operator()//初始化函数
{
    Operator *op = std::make_unique<Operator>().release();//创建了一个智能指针，已经指向了一个对象



    DoraInitResult_t result = {.operator_context = (void *)op};//这里新建了一个结构体，“内容”指向了一个智能指针，“事件”指向NULL
    return result;
}

extern "C" DoraResult_t dora_drop_operator(void *operator_context)//删除函数
{
    delete (Operator *)operator_context;//调用析构函数，因为这个示例里面构造函数啥都没有，析构也没写。
    return {};//直接返回一个空结构体，不装了
}

extern "C" OnEventResult_t dora_on_event(//事件函数，一个很重要的问题是搞清楚里面的三个形参分别是干什么的
    const RawEvent_t *event,             //应该是输入事件，
    const SendOutput_t *send_output,     //这个玩意规定了输出内容的形式，具体规定方法是在里面的call函数，就是 数据==自己设计怎么做==》字节流==call函数==》result，输出内容是一个字节流，具体怎么读，《鬼知道》
    void *operator_context)
{
    if (event->input != NULL)
    {
        // input event
        Input_t *input = event->input;
        std::string id((char *)input->id.ptr, input->id.len);//id是干什么用的？不是在yml里写过了吗？是不是用来排错用的？


std::shared_ptr<PointCloudMsg> msg;
uint16_t *seq=(uint16_t*)input->data.ptr;
msg->seq=*seq;
double *timestamp=(double*)(input->data.ptr+8);
msg->timestamp=*timestamp;
int pointlen=(input->data.len-16)/16;
PointXYZI *pointPtr=(PointXYZI*)(input->data.ptr+16);
for (int i=0;i<pointlen;++i){
  msg->points[i]=pointPtr[i];
}
        pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_pointcloud(new pcl::PointCloud<pcl::PointXYZI>);
    pcl_pointcloud->points.swap(msg->points);
    pcl_pointcloud->height = msg->height;
    pcl_pointcloud->width = msg->width;
    pcl_pointcloud->is_dense = msg->is_dense;

    PointCloudColorHandlerGenericField<pcl::PointXYZI> point_color_handle(pcl_pointcloud, "intensity");

    {
      const std::lock_guard<std::mutex> lock(mtx_viewer);
      pcl_viewer->updatePointCloud<pcl::PointXYZI>(pcl_pointcloud, point_color_handle, "rslidar");
    }

          pcl_viewer = std::make_shared<PCLVisualizer>("RSPointCloudViewer");
  pcl_viewer->setBackgroundColor(0.0, 0.0, 0.0);
  pcl_viewer->addCoordinateSystem(1.0);

  pcl_viewer->addPointCloud<pcl::PointXYZI>(pcl_pointcloud, "rslidar");
  pcl_viewer->setPointCloudRenderingProperties(PCL_VISUALIZER_POINT_SIZE, 2, "rslidar");


        const char *out_id = "half-status";
        char *out_id_heap = strdup(out_id);

        size_t out_data_len = 1;
        uint8_t *out_data_heap = NULL;//这里申请了内存，但是我们不管删，发一次，申请一次内存

        Output_t output = {.id = {//输出的id
                               .ptr = (uint8_t *)out_id_heap,
                               .len = strlen(out_id_heap),
                               .cap = strlen(out_id_heap) + 1,
                           },
                           .data = {.ptr = out_data_heap, .len = out_data_len, .cap = out_data_len}};//这里其实还可以附一份metadata，它没用

        DoraResult_t send_result = (send_output->send_output.call)(send_output->send_output.env_ptr, output);//这里用了输入的call函数处理输出的内容，结果装在一个字节流里

        OnEventResult_t result = {.result = send_result, .status = DORA_STATUS_CONTINUE};
        return result;
    }
    if (event->stop)
    {
        printf("C operator received stop event\n");
    }

    OnEventResult_t result = {.status = DORA_STATUS_CONTINUE};
    return result;
}