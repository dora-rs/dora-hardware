extern "C"
{
#include "./operator_api.h"
}

#include <memory>
#include <iostream>
#include <vector>
#include <string.h>

struct PointXYZI
{
  float x;
  float y;
  float z;
  uint8_t intensity;
};

class Operator
{
public:
    Operator();
    ~Operator();
};

Operator::Operator() {}//构造函数
Operator::~Operator(){}

extern "C" DoraInitResult_t dora_init_operator()//初始化函数
{
    Operator *op = NULL;//std::make_unique<Operator>().release();//创建了一个智能指针，已经指向了一个对象

    DoraInitResult_t result = {.operator_context = (void *)op};//这里新建了一个结构体，“内容”指向了一个智能指针，“事件”指向NULL
    return result;
}

extern "C" DoraResult_t dora_drop_operator(void *operator_context)//删除函数
{
    //delete (Operator *)operator_context;//调用析构函数，因为这个示例里面构造函数啥都没有，析构也没写。
    return {};//直接返回一个空结构体，不装了
}

extern "C" OnEventResult_t dora_on_event(//事件函数，一个很重要的问题是搞清楚里面的三个形参分别是干什么的
    const RawEvent_t *event,             //应该是输入事件，
    const SendOutput_t *send_output,     //这个玩意规定了输出内容的形式，具体规定方法是在里面的call函数，就是 数据==自己设计怎么做==》字节流==call函数==》result，输出内容是一个字节流，具体怎么读，《鬼知道》
    void *operator_context)
{
    if (event->input != NULL)
    {
        // input event
        Input_t *input = event->input;
        uint16_t *seq=(uint16_t*)input->data.ptr;
        double *timestamp =(double*)(input->data.ptr+8);
        PointXYZI *pointPtr=(PointXYZI*)(input->data.ptr+16);
        std::cout<<"seq:"<<(int)*seq<<std::endl;
        std::cout<<"timestamp:"<<(double)*timestamp<<std::endl;
        std::cout<<"length"<<input->data.len<<std::endl;
        for(int i=0;i<100;++i){
            std::cout<<"point"<<i<<":x="<<pointPtr->x<<" y="<<pointPtr->y<<" z="<<pointPtr->z<<" i="<<(int)pointPtr->intensity<<std::endl;
            ++pointPtr;
        }
        const char *out_id = NULL;
        char *out_id_heap = strdup(out_id);

        size_t out_data_len = 0;
        uint8_t *out_data_heap = NULL;//这里申请了内存，但是我们不管删，发一次，申请一次内存
        //*out_data_heap = 0;

        Output_t output = {.id = {//输出的id
                               .ptr = (uint8_t *)out_id_heap,
                               .len = 0,
                               .cap = 0,
                           },
                           .data = {.ptr = out_data_heap, .len = out_data_len, .cap = out_data_len}};//这里其实还可以附一份metadata，它没用

        DoraResult_t send_result = (send_output->send_output.call)(send_output->send_output.env_ptr, output);//这里用了输入的call函数处理输出的内容，结果装在一个字节流里

        OnEventResult_t result = {.result = send_result, .status = DORA_STATUS_CONTINUE};
        return result;
    }
    if (event->stop)
    {
        printf("C operator received stop event\n");
    }

    OnEventResult_t result = {.status = DORA_STATUS_CONTINUE};
    return result;
}



// int main(){
//   RawEvent_t mainEvent,*pt=&mainEvent;
//   mainEvent.stop=false;
//   mainEvent.input->id.len=10;
//   mainEvent.input->data.cap=32;
//   mainEvent.input->data.len=32;
//   double* ptr=new double[4];
//   u_int16_t *ptr16=(u_int16_t*)ptr;
//   *ptr16=(u_int16_t)257;
//   *(++ptr)=233.0;
//   PointXYZI point,*pointptr=(PointXYZI*)(++ptr);
//   point.intensity=(uint8_t)33;
//   point.x=15.0;
//   point.y=25.0;
//   point.z=35.0;
//   *pointptr=point;
//   mainEvent.input->data.ptr=(u_int8_t*)(ptr-2);
//   SendOutput_t *out;
//   DoraInitResult_t r=dora_init_operator();
//   OnEventResult_t result= dora_on_event(
//     &mainEvent,             
//     out,
//     r.operator_context);
//     //delete result.result.
//     return 0;
// }